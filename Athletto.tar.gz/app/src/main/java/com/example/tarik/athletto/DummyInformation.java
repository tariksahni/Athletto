package com.example.tarik.athletto;

/**
 * Created by tarik on 8/3/16.
 */
//dummy data
public class DummyInformation {
    public  String name;
    public  String hometown;
    public  int age;
    public  String prefrences;


}
